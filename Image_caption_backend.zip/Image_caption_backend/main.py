import matplotlib.pyplot as plt
import tensorflow as tf
#from keras.backend.tensorflow_backend import set_session
import keras
import sys, time, os, warnings
import numpy as np
import pandas as pd
from collections import Counter
import pathlib
import string

from keras.applications import VGG16
from keras import models
from keras.preprocessing.image import load_img, img_to_array
from keras.applications.vgg16 import preprocess_input
from collections import OrderedDict
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical
from keras import layers
from keras.layers import Input, Flatten, Dropout, Activation
#from keras.layers.advanced_activations import LeakyReLU, PReLU
from time import time
from keras.callbacks import TensorBoard

import numpy as np
from PIL import Image
import requests
from io import BytesIO

import requests
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import pickle
import json
from keras.models import load_model

from googletrans import Translator
import speech_recognition as spr
from gtts import gTTS
import os
import pyttsx3

from beam import *
from colorama import Fore, Style

def extract_features_from_url(url):
    npix = 224  # Image size
    target_size = (npix, npix)
    images = OrderedDict()

    response = requests.get(url)
    image_data = response.content
    image = Image.open(BytesIO(image_data))
    image = image.resize(target_size)
    image = img_to_array(image)
    image = preprocess_input(image)
    y_pred = modelvgg.predict(image.reshape((1,) + image.shape[:3]))
    features = y_pred.flatten()

    return features

def predict_caption(image):
    '''
    image.shape = (1,4462)
    '''

    in_text = 'startseq'

    for iword in range(maxlen):
      sequence = tokenizers.texts_to_sequences([in_text])[0]

      sequence = pad_sequences([sequence],maxlen)
      #print("Len: ",[sequence],maxlen,image,loaded_model)
      yhat = loaded_model.predict([image,sequence],verbose=0)
      yhat = np.argmax(yhat)
      newword = index_word[yhat]
      in_text += " " + newword
      if newword == "endseq":
          break
    return(in_text)

def translator(caption,lang):
        translator = Translator()
        text_to_translate = translator.translate(caption,dest=lang)
        translated_cap = text_to_translate.text
        return translated_cap

def main(url,lang):
    global modelvgg, maxlen, tokenizers, loaded_model, index_word

    npic = 5
    npix = 224
    maxlen = 28
    target_size = (npix,npix,3)

    with open("Image_caption_backend\index_word.pkl", 'rb') as fp:
        tokenizers = pickle.load(fp)

    index_word = dict([(index,word) for word, index in tokenizers.word_index.items()])
    loaded_model = load_model('Image_caption_backend\image_model.h5')

    # Define your VGG16 model
    modelvgg = VGG16(include_top=True, weights=None)
    modelvgg.load_weights(r"Image_caption_backend\vgg16_weights_tf_dim_ordering_tf_kernels.h5")
    modelvgg.layers.pop()
    modelvgg = models.Model(inputs=modelvgg.inputs, outputs=modelvgg.layers[-2].output)
    image_urls = [url]

    count = 1

    lang_dict = {'es':'Spanish','fr':'French','de':'German','it':"Italian"}

    for image_url in image_urls:
        image_feature = extract_features_from_url(image_url)

        image_load = Image.open(BytesIO(requests.get(image_url).content))
        image_load.save("Image_caption_frontend/src/assets/inp.jpg")

        caption = predict_caption(image_feature.reshape(1,len(image_feature)))
        caption = caption.replace("startseq"," ").replace("endseq"," ").replace("1/1"," ")

        print("\n" + "Caption in English:\n" + caption)
        trans_cap = translator(caption,lang)
        print("\n" + f"Caption in {lang_dict[lang]}:\n" + trans_cap)

search_query = sys.argv[1:]
main(search_query[0],search_query[1])

