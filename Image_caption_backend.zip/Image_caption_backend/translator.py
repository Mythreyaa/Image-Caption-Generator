from googletrans import Translator
import sys

def translate_text(text, target_language):
    translator = Translator()
    print(text,target_language)
    translation = translator.translate(text, dest=target_language)
    print(translation.text)

    #return translation.text

target_language = 'es' 

caption = sys.argv[1:]
translate_cap = translate_text(caption[0],target_language)

