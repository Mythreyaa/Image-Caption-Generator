beam_width = 3  

def get_top_k_candidates(next_word_probs, beam_width):
    flat_probs = next_word_probs.flatten()
    top_k_indices = flat_probs.argsort()[-beam_width:][::-1]

    row_indices = top_k_indices // next_word_probs.shape[1]
    col_indices = top_k_indices % next_word_probs.shape[1]
    top_k_candidates = [(index, next_word_probs[row, col]) for index, (row, col) in enumerate(zip(row_indices, col_indices))]

    return top_k_candidates

def beam_search_decode(model, image_features, beam_width, max_length):
    beam = [(["<start>"], 1.0)]

    for _ in range(max_length):
        candidates = []

        for seq, score in beam:
            last_word = seq[-1]
            next_word_probs = model.predict_next_word(image_features, seq)

            top_candidates = get_top_k_candidates(next_word_probs, beam_width)

            for candidate, candidate_prob in top_candidates:
                candidates.append((seq + [candidate], score * candidate_prob))

        beam = sorted(candidates, key=lambda x: x[1], reverse=True)[:beam_width]

    best_sequence, _ = max(beam, key=lambda x: x[1])
    return best_sequence[1:]  






