//import SearchCont  from "../SearchCont/SearchCont.jsx";


const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const { exec } = require("child_process"); // Import the child_process module
const app = express();
const port = 3001;



app.use(bodyParser.json());
app.use(cors());



app.post("/print-search-query", (req, res) => {
  const searchQuery = req.body.searchText;
  const captionLang = req.body.capLang;

  console.log("Search Query: ", searchQuery, "Caption Language: ",captionLang);
  
  // Execute the Python script with searchQuery as an argument
  const pythonScriptPath = "Image_caption_backend/dataset.py"; // Update the path
  const pythonProcess = exec(`python "${pythonScriptPath}" "${searchQuery}" "${captionLang}"`, (error, stdout, stderr) => {
    if (error) {
      console.error(error);
      res.status(500).send("An error occurred");
    } 
    else {
      const caption = stdout;
      console.log("Python script output:\n", caption);
      //const searchContMarkup = SearchCont({ caption });
      res.send(caption);
      

      
    }
  });
  
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});















// console.log("1");
// console.log("caption: ",caption)
// const pythontranspro = exec(`python "${"Image_caption_backend/translator.py"}" "heeee"`, (error, stdout, stderr) => {
//   console.log("2");
//   if (error) {
//     console.log("3");
//     console.error(error);
//     res.status(500).send("An error occurred");
//   } 
//   else {
//     console.log("4");
//     const trans_caption = stdout;
//     //console.log("5");
//     console.log("5",trans_caption);
//     console.log("Python script output  1:\n", trans_caption);
//     //const searchContMarkup = SearchCont({ caption });
//     //res.send(trans_caption);
//     return trans_caption;
    
//   }
// });