import React from 'react';
import {Header, LandingContent, SearchCont} from "./components";
import { useState, useEffect } from "react";



const App = () => {
  const [captions, setCaptions] = useState('');
  return (
    <div>
      <Header captions={captions} />
      {/* Render AnotherComponent and pass captions as a prop */}
      {/* <SearchCont captions={captions} /> */}
    </div>
  );
}

export default App