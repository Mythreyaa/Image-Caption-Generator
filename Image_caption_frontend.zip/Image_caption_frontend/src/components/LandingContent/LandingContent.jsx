import React from 'react';
import "./LandingContent.css";

const LandingContent = () => {
  return (
    <div>landingcont</div>
  )
}

export default LandingContent