
import React from 'react';
import "./Header.css";
import { useState, useEffect } from "react";

import 'bootstrap/dist/css/bootstrap.min.css'; // Import Bootstrap CSS
import { Modal,Button, Container, Row, Col, Navbar, Nav, Form, FormControl } from 'react-bootstrap';
import {store} from 'state-pool';
import SearchCont from './SearchCont';

const Header = () => {

  const [searchInput, setSearchInput] = useState('');
  const [captionLanguage, setCaplang] = useState('');
  const [captions, setOutput] = useState('');
  const [showModal, setShowModal] = useState(false);
  

  const executePythonScript = () => {
    
    fetch("http://localhost:3001/print-search-query", { // Update the URL to match your server
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ searchText: searchInput, capLang:captionLanguage }),
  })
    .then((response) => response.text())
    .then((data) => {
      console.log(data);
      setOutput(data);
      setShowModal(true);
      console.log("Cap from header: ",{captions});
      
    })
    .catch((error) => {
      console.error("Error sending search request:", error);
    });
  };

  const handleClose = () => setShowModal(false);

  return (
      <header>
        <Container fluid>
          <Row>
            <Col>
            <Navbar bg="light" expand="lg" className='MainNavbar'>
            <Navbar.Brand href="#" className="logo">PicLingo</Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" className='sidebar'/>
                <Navbar.Collapse id="basic-navbar-nav" className="justify-content-end">
                  <Nav className="me-auto">
                    

                    <Nav.Link href="#" className='right-side'>About Us</Nav.Link>
                    <Nav.Link href="#" className='right-side'>How it Works</Nav.Link>
                    <Nav.Link href="#" className='right-side'>Sign Out</Nav.Link>
                    <Button className="cont-button">Contact Us</Button>
                  </Nav>
                  
                </Navbar.Collapse>
           
            </Navbar>
            </Col>
          </Row>
          <Row>
              <Col lg={6} className='TagAlign'>
                <h1 className="MainTag1">
                  <span className="FramesHeader">
                    <span className="Frames">Frames</span>
                    <span className="Unveiled"> Unveiled,</span>
                  </span>
                </h1>
               
                <h1 className="MainTag2">
                  <span className="WordsHeader">
                    <span className="Words">Words</span>
                    <span className="Tailored"> Tailored</span>
                  </span>
                </h1><br></br>
                <h3 className='SubTag'>Your Pictures, Your Words, Any Language.</h3>
                <br></br>
                <FormControl className="input-box"
                  
                    type="text"
                    placeholder="Paste or Type the URL of the image"
                    value={searchInput}
                    onChange={(e) => setSearchInput(e.target.value)}
                  
                />
                <br></br>
        <br></br>
        <form action="#"                    >
          <div class="parent-container">
            <select className='drop-down' name="languages" id="lang"
             value={captionLanguage}
             onChange={(e) => setCaplang(e.target.value)}>
                <option selected>Select a Language</option>
                        <option value="es">Spanish</option>
                        <option value="fr">French</option>
                        <option value="de">German</option>
                        <option value="it">Italian</option>

      </select></div>
      </form><br></br>

      <Button className="gen-button" onClick={executePythonScript}>Start Generating Captions!</Button>
     
      </Col>

    <Col lg={6} className="ImagesContainer">
    </Col>

      </Row>
      </Container>
        <Modal show={showModal} className='Pop-up'>
        <Modal.Header>
          <Modal.Title className='Pop-up-title'>Captions for the image!</Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }}>
        <br></br>
          <img src="src/assets/inp.jpg" alt="Get your results here" style={{ width: '20%', height: 'auto' }} />

          <div style={{ marginLeft: '10px' }} className='captions'>
        
           {/* Split captions into lines */}
        {captions.split('\n').slice(3).map((caption, index) => (
          <p key={index}>{caption}</p>
        ))}
          </div>
        </div>
        </Modal.Body>
        <Modal.Footer>
          <Button className="pop-button" variant="secondary" onClick={handleClose} >
            Generate Again
          </Button>
        </Modal.Footer>
      </Modal>
      </header>
    );
};

export default Header