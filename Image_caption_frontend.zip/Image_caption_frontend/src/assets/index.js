import land_imag1 from "./land_imag1.png";
import land_imag2 from "./land_imag2.png";
import cont_button from "./cont_button.png";
import gen_button from "./gen_button.png";

export {land_imag1,land_imag2,cont_button,gen_button};